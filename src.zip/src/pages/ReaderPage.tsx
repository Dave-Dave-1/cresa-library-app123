import { useEffect, useRef, useState, type CSSProperties } from 'react'
import mammoth from 'mammoth'
import { Document, Page as PdfPage, pdfjs } from 'react-pdf'
import 'react-pdf/dist/Page/AnnotationLayer.css'
import 'react-pdf/dist/Page/TextLayer.css'
import type { Resource } from '../types'
import { Icon } from '../components/ui'

pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString()

type ReaderProps = { resource: Resource; onExit: () => void; setToast: (message: string) => void; initialPage: number; aiEnabled: boolean; onProgress: (page: number, total: number, completed?: boolean, readingSeconds?: number) => void }

export function ReaderPage({ resource, onExit, setToast, initialPage, aiEnabled, onProgress }: ReaderProps) {
  const [page, setPage] = useState(Math.max(1, initialPage)); const [totalPages, setTotalPages] = useState(0); const [zoom, setZoom] = useState(1); const [fit, setFit] = useState<'width' | 'page'>('width'); const [pdfData, setPdfData] = useState<ArrayBuffer | null>(null); const [docxHtml, setDocxHtml] = useState(''); const [status, setStatus] = useState('Opening reader...'); const [error, setError] = useState('')
  const root = useRef<HTMLDivElement>(null); const progress = useRef(onProgress); const requestId = useRef(0); const isPdf = resource.format.toUpperCase() === 'PDF'; const isDocx = resource.format.toUpperCase() === 'DOCX'
  useEffect(() => { progress.current = onProgress }, [onProgress])
  useEffect(() => {
    const controller = new AbortController()
    const activeRequest = ++requestId.current
    setStatus(`Loading ${resource.format} safely inside Cresa Reader...`); setError(''); setPdfData(null); setDocxHtml(''); setTotalPages(0); setPage(Math.max(1, initialPage))
    console.info('[Cresa Reader] loading', resource.downloadUrl)
    if (!isPdf && !isDocx) { setStatus(`${resource.format} remains in Reader mode. An in-app preview is not available for this format yet.`); return () => controller.abort() }
    const fetchBookBytes = async () => {
      const bookUrl = new URL(resource.downloadUrl, window.location.origin).toString()
      const response = await fetch(bookUrl, { signal: controller.signal, headers: { Accept: isPdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' } })
      console.info('[Cresa Reader] streamed book response', { status: response.status, contentType: response.headers.get('content-type'), contentLength: response.headers.get('content-length') })
      if (!response.ok) throw new Error(`File request failed: ${response.status}`)
      const bytes = await response.arrayBuffer()
      if (!bytes.byteLength) throw new Error('The local book stream returned no data.')
      return bytes
    }
    void fetchBookBytes()
      .then(async data => {
        if (controller.signal.aborted || requestId.current !== activeRequest) return
        console.info('[Cresa Reader] bytes received', data.byteLength)
        if (data.byteLength === 0) throw new Error('The server returned an empty file.')
        const head = new Uint8Array(data.slice(0, 4))
        const looksLikePdf = head[0] === 0x25 && head[1] === 0x50 && head[2] === 0x44 && head[3] === 0x46 // "%PDF"
        const looksLikeZip = head[0] === 0x50 && head[1] === 0x4b // "PK" (docx is a zip container)
        if (isPdf && !looksLikePdf) throw new Error("This link didn't return a real PDF — the reader received something else (an HTML page or broken file) instead of book data.")
        if (isDocx && !looksLikeZip) throw new Error("This link didn't return a real Word document — the reader received something else (an HTML page or broken file) instead of book data.")
        if (isPdf) { setPdfData(data); setStatus('PDF received. Rendering page...') }
        else { setDocxHtml((await mammoth.convertToHtml({ arrayBuffer: data })).value); setStatus('Word document ready.') }
      })
      .catch(reason => {
        if (reason instanceof DOMException && reason.name === 'AbortError') return
        if (requestId.current !== activeRequest) return
        const message = reason instanceof Error ? reason.message : 'Unknown error'
        console.error('[Cresa Reader] load error', reason)
        setError(message); setStatus(`Could not open this book: ${message}`)
      })
    return () => controller.abort()
  }, [resource.downloadUrl, resource.format, initialPage, isPdf, isDocx])
  useEffect(() => { if (totalPages) progress.current(page, totalPages, page === totalPages) }, [page, totalPages])
  useEffect(() => { let savedAt = Date.now(); const save = () => { const now = Date.now(); progress.current(page, totalPages || page, page === totalPages, Math.max(1, Math.round((now - savedAt) / 1000))); savedAt = now }; const timer = window.setInterval(save, 15_000); return () => { window.clearInterval(timer); save() } }, [page, totalPages])
  useEffect(() => { const handler = (event: KeyboardEvent) => { if (event.target instanceof HTMLInputElement) return; if (event.key === 'ArrowLeft') setPage(value => Math.max(1, value - 1)); if (event.key === 'ArrowRight') setPage(value => Math.min(totalPages || value, value + 1)); if (event.key === '+') setZoom(value => Math.min(1.8, value + .1)); if (event.key === '-') setZoom(value => Math.max(.6, value - .1)); if (event.key.toLowerCase() === 'f') void root.current?.requestFullscreen() }; window.addEventListener('keydown', handler); return () => window.removeEventListener('keydown', handler) }, [totalPages])
  const download = async () => { try { const response = await fetch(resource.downloadUrl); if (!response.ok) throw new Error(); const objectUrl = URL.createObjectURL(await response.blob()); const link = document.createElement('a'); link.href = objectUrl; link.download = resource.downloadUrl.split('/').pop() ?? resource.title; link.click(); URL.revokeObjectURL(objectUrl); setToast('Your download is starting.') } catch { setToast('Download could not be started.') } }
  const width = Math.max(320, (root.current?.clientWidth ?? 950) - (aiEnabled ? 330 : 90))
  return <div className="reader-page" ref={root}><header className="reader-header"><button onClick={onExit}><Icon name="close" />Close reader</button><div><strong>{resource.courseCode} · {resource.title}</strong><span>{resource.format} · {resource.fileSize}</span></div><div className="reader-tools"><button onClick={() => setZoom(value => Math.max(.6, value - .1))}>-</button><span>{Math.round(zoom * 100)}%</span><button onClick={() => setZoom(value => Math.min(1.8, value + .1))}>+</button><button onClick={() => setFit(value => value === 'width' ? 'page' : 'width')}>{fit === 'width' ? 'Fit page' : 'Fit width'}</button><button onClick={() => void root.current?.requestFullscreen()} aria-label="Fullscreen"><Icon name="eye" size={16} /></button><button className="reader-download" onClick={() => { void download() }}><Icon name="download" />Download</button></div></header><div className={`reader-layout modern-reader ${aiEnabled ? '' : 'reader-no-ai'}`}><main className="pdf-workspace"><div className="reader-commandbar">{isPdf ? <><button disabled={page <= 1} onClick={() => setPage(value => value - 1)}><Icon name="arrow" size={14} />Previous</button><label>Page <input type="number" min="1" max={totalPages || 1} value={page} onChange={event => setPage(Math.min(Math.max(1, Number(event.target.value) || 1), totalPages || 1))} /> of {totalPages || '-'}</label><button disabled={!totalPages || page >= totalPages} onClick={() => setPage(value => value + 1)}>Next <Icon name="arrow" size={14} /></button></> : <span className="reader-format-label">{resource.format} reader</span>}</div>{!pdfData && !docxHtml && !error && <div className="reader-state"><Icon name="clock" size={24} /><strong>Preparing your document</strong><span>{status}</span></div>}{error && <div className="reader-state error"><Icon name="close" size={24} /><strong>Reader preview unavailable</strong><span>{status}</span></div>}{isPdf && pdfData && !error && <div className={`pdf-page-shell fit-${fit}`} style={{ '--reader-zoom': zoom } as CSSProperties}><Document file={{ data: pdfData }} loading={<div className="reader-state">Rendering PDF...</div>} onLoadSuccess={({ numPages }) => { console.info('[Cresa Reader] PDF ready', numPages); setTotalPages(numPages); setStatus(`PDF ready: ${numPages} pages.`) }} onLoadError={reason => { console.error('[Cresa Reader] PDF error', reason); setError(reason.message); setStatus(`PDF renderer error: ${reason.message}`) }}><PdfPage pageNumber={page} width={fit === 'width' ? width : undefined} scale={fit === 'page' ? zoom : 1} renderTextLayer renderAnnotationLayer /></Document></div>}{isDocx && docxHtml && !error && <article className="docx-preview" dangerouslySetInnerHTML={{ __html: docxHtml }} />}{!isPdf && !isDocx && !error && <div className="reader-state"><Icon name="file" size={24} /><strong>In-app preview is not available for {resource.format}</strong><span>This page remains inside the website. The file will never download unless you press Download.</span></div>}</main>{aiEnabled && <aside className="reader-ai"><div><span><Icon name="sparkle" /></span><strong>Reading companion</strong><p>Your reading time is being recorded.</p></div><button onClick={() => setToast('Summary tools are ready for this page.')}>Summarise this page</button><button onClick={() => setToast('Study questions are ready for this page.')}>Make study questions</button></aside>}</div></div>
}
