import type { AuthUser, Role } from './store'

type Result<T> = { ok: true; data: T } | { ok: false; error: string }
type ApiUser = AuthUser & { profile?: AuthUser['profile'] }

const request = async <T>(path: string, options: RequestInit = {}): Promise<Result<T>> => {
  try {
    const response = await fetch(path, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...options.headers },
    })
    const body = await response.json() as T & { ok?: boolean; error?: string }
    if (!response.ok || body.ok === false) return { ok: false, error: body.error ?? 'The request could not be completed.' }
    return { ok: true, data: body }
  } catch { return { ok: false, error: 'The Cresa API server is unavailable.' } }
}

const bearer = (token: string) => ({ Authorization: 'Bearer ' + token })

export const api = {
  register: (input: { name: string; identifier: string; password: string; role: Exclude<Role, 'administrator'>; lecturerEmail?: string }) =>
    request<{ ok: true; requiresVerification: boolean }>('/api/auth/register', { method: 'POST', body: JSON.stringify(input) }),
  login: (identifier: string, password: string) =>
    request<{ ok: true; user: ApiUser; sessionToken: string }>('/api/auth/login', { method: 'POST', body: JSON.stringify({ identifier, password }) }),
  me: (token: string) => request<{ ok: true; user: ApiUser }>('/api/me', { headers: bearer(token) }),
  updateProfile: (token: string, input: { name: string; institution: string; course: string; avatarUrl?: string }) =>
    request<{ ok: true; user: ApiUser }>('/api/me/profile', { method: 'PATCH', headers: bearer(token), body: JSON.stringify(input) }),
  updatePreferences: (token: string, input: Record<string, unknown>) =>
    request<{ ok: true; user: ApiUser }>('/api/me/preferences', { method: 'PATCH', headers: bearer(token), body: JSON.stringify(input) }),
  changePassword: (token: string, currentPassword: string, newPassword: string) =>
    request<{ ok: true }>('/api/me/change-password', { method: 'POST', headers: bearer(token), body: JSON.stringify({ currentPassword, newPassword }) }),
  requestEmailChange: (token: string, email: string) =>
    request<{ ok: true }>('/api/me/email-change/request', { method: 'POST', headers: bearer(token), body: JSON.stringify({ email }) }),
  confirmEmailChange: (token: string, code: string) =>
    request<{ ok: true; user: ApiUser }>('/api/me/email-change/confirm', { method: 'POST', headers: bearer(token), body: JSON.stringify({ code }) }),
  deleteAccount: (token: string) =>
    request<{ ok: true }>('/api/me', { method: 'DELETE', headers: bearer(token) }),
  listUsers: (token: string) => request<{ ok: true; users: ApiUser[] }>('/api/admin/users', { headers: bearer(token) }),
  deleteStudent: (token: string, id: string) => request<{ ok: true }>(`/api/admin/users/${id}`, { method: 'DELETE', headers: bearer(token) }),
}
