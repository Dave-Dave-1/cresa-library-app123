import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { resources } from './data/resources'
import { Icon } from './components/ui'
import { OverviewPage } from './pages/OverviewPage'
import { LibraryPage } from './pages/LibraryPage'
import { DiscoverPage } from './pages/DiscoverPage'
import { SavedPage } from './pages/SavedPage'
import { CommunityPage } from './pages/CommunityPage'
import { SettingsPage } from './pages/SettingsPage'
import { ResourceDetailsPage } from './pages/ResourceDetailsPage'
import { ReaderPage } from './pages/ReaderPage'
import { LecturerDashboardPage } from './pages/LecturerDashboardPage'
import type { IconName, Page, Resource } from './types'
import { AuthPage } from './auth/AuthPage'
import { deleteAccount, getSession, getSessionToken, logout, saveSession, type AuthUser } from './auth/store'
import { api } from './auth/api'
import { getReadingActivity, upsertReadingActivity, type ReadingActivity } from './data/readingActivity'

const navigation: { label: Exclude<Page, 'Resource details' | 'Reader'>; icon: IconName }[] = [
  { label: 'Overview', icon: 'grid' },
  { label: 'My Library', icon: 'book' },
  { label: 'Discover', icon: 'compass' },
  { label: 'Saved for later', icon: 'bookmark' },
  { label: 'Community', icon: 'users' },
  { label: 'Settings', icon: 'settings' },
]

export default function App() {
  const [user, setUser] = useState<AuthUser | null>(() => getSession())
  const [page, setPage] = useState<Page>('Overview')
  const [open, setOpen] = useState(true)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [toast, setToast] = useState('')
  const [selected, setSelected] = useState<Resource>(resources[0])
  const [saved, setSaved] = useState<number[]>(resources.filter(item => item.saved).map(item => item.id))
  const [activity, setActivity] = useState<ReadingActivity[]>(() => getReadingActivity())
  const searchRef = useRef<HTMLInputElement>(null)
  const searchResults = useMemo(() => resources.filter(item => `${item.title} ${item.author} ${item.kind}`.toLowerCase().includes(query.toLowerCase())), [query])

  useEffect(() => {
    if (!toast) return
    const timer = window.setTimeout(() => setToast(''), 2800)
    return () => window.clearTimeout(timer)
  }, [toast])
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === '/' && document.activeElement?.tagName !== 'INPUT') { event.preventDefault(); searchRef.current?.focus() }
      if (event.key === 'Escape') setMobileOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])
  useEffect(() => {
    if (!user) return
    const timer = window.setInterval(() => {
      if (!getSession()) setUser(null)
    }, 60_000)
    return () => window.clearInterval(timer)
  }, [user])
  useEffect(() => {
    const preference = user?.profile?.theme ?? 'system'
    const resolved = preference === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : preference
    document.documentElement.dataset.theme = resolved
    document.documentElement.lang = user?.profile?.language ?? 'en'
  }, [user?.profile?.theme, user?.profile?.language])

  const go = (next: Page) => {
    if (next === 'Lecturer dashboard' && user?.role !== 'lecturer' && user?.role !== 'administrator') { setToast('The lecturer dashboard is available to lecturer accounts only.'); return }
    setPage(next); setMobileOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  const showResource = (resource: Resource) => { setSelected(resource); go('Resource details') }
  const toggleSaved = (resource: Resource) => {
    const wasSaved = saved.includes(resource.id)
    setSaved(current => wasSaved ? current.filter(id => id !== resource.id) : [...current, resource.id])
    setToast(wasSaved ? 'Removed from saved items.' : 'Saved for later.')
  }
  const pageTitle = page === 'Resource details' ? selected.title : page === 'Reader' ? 'Reading workspace' : page
  const initials = user?.name.split(' ').map(part => part[0]).slice(0, 2).join('').toUpperCase() ?? 'JD'
  const handleLogout = () => { logout(); setUser(null) }
  const handleDelete = async () => {
    if (!user || !window.confirm('Request deletion of this account? You will be signed out.')) return
    const token = getSessionToken()
    if (token) {
      const result = await api.deleteAccount(token)
      if (!result.ok) { setToast(result.error); return }
    } else deleteAccount(user)
    logout()
    setUser(null)
  }
  const updateUser = (updatedUser: AuthUser) => {
    setUser(updatedUser)
    saveSession(updatedUser, getSessionToken() ?? undefined)
  }
  const updateProgress = useCallback((resource: Resource, currentPage: number, totalPages: number, completed = false, readingSeconds?: number) => {
    setActivity(current => {
      const record = current.find(item => item.resourceId === resource.id)
      const next = { resourceId: resource.id, currentPage, progress: totalPages ? Math.round(currentPage / totalPages * 100) : 0, lastReadAt: new Date().toISOString(), completed, note: record?.note ?? '', readingSeconds: (record?.readingSeconds ?? 0) + (readingSeconds ?? 0) }
      return upsertReadingActivity(current, next)
    })
  }, [])

  if (!user) return <AuthPage onAuthenticated={(authenticatedUser) => { setUser(authenticatedUser); setPage(authenticatedUser.role === 'lecturer' ? 'Lecturer dashboard' : 'Overview') }} />

  return <main className={`blue-app ${open ? '' : 'nav-collapsed'}`}>
    <aside className={`side-nav ${mobileOpen ? 'mobile-open' : ''}`} aria-label="Primary navigation">
      <div className="nav-brand"><span className="brand-glyph">C</span><span className="brand-name">Cresa<span>space</span></span><button className="nav-collapse" aria-label={open ? 'Collapse navigation' : 'Expand navigation'} onClick={() => setOpen(!open)}><Icon name={open ? 'close' : 'menu'} size={17} /></button></div>
      <div className="nav-profile"><span className="profile-photo">{initials}</span><div><strong>{user.name}</strong><small>{user.role}</small></div><span className="online-dot" /></div>
      <nav className="main-nav">{navigation.slice(0, 4).map(item => <button key={item.label} aria-label={item.label} title={item.label} className={page === item.label ? 'active' : ''} onClick={() => go(item.label)}><Icon name={item.icon} /><span>{item.label}</span>{item.label === 'Saved for later' && <b>{saved.length}</b>}</button>)}</nav>
      <p className="nav-caption">Workspace</p>
      <nav className="main-nav compact-nav">{(user.role === 'lecturer' || user.role === 'administrator') && <button aria-label="Lecturer dashboard" title="Lecturer dashboard" className={page === 'Lecturer dashboard' ? 'active' : ''} onClick={() => go('Lecturer dashboard')}><Icon name="trend" /><span>Lecturer dashboard</span></button>}{navigation.slice(4).map(item => <button key={item.label} aria-label={item.label} title={item.label} className={page === item.label ? 'active' : ''} onClick={() => go(item.label)}><Icon name={item.icon} /><span>{item.label}</span></button>)}</nav>
      <button className="nav-ai-button" onClick={() => setToast(user.profile?.aiEnabled === false ? 'Enable the AI reading companion in Preferences to use it.' : 'Your AI reading companion is available inside Reader mode.')}><span><Icon name="sparkle" /></span><div><strong>AI companion</strong><small>{user.profile?.aiEnabled === false ? 'Disabled in preferences' : 'Ready in the reader'}</small></div><Icon name="chevron" size={14} /></button>
      <button className="help-button" onClick={() => setToast('Help centre is ready to connect.')}><Icon name="help" /><span>Help & support</span></button>
      <button className="signout-button" onClick={handleLogout}><Icon name="close" size={16} /><span>Sign out</span></button>
    </aside>
    {mobileOpen && <button className="nav-backdrop" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
    <section className="main-content">
      <header className="app-header"><button className="mobile-toggle" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Icon name="menu" /></button><div className="crumb">My space <Icon name="chevron" size={14} /> <strong>{pageTitle}</strong></div><label className="search"><Icon name="search" /><input ref={searchRef} value={query} onChange={event => { setQuery(event.target.value); if (event.target.value) setPage('Discover') }} placeholder="Search your library..." /><kbd>/</kbd></label><button className="round-button" aria-label="Notifications" onClick={() => setToast(user.profile?.notificationsEnabled === false ? 'Reading reminders are disabled in Preferences.' : 'No new notifications.')}><Icon name="bell" /><i /></button><button className="header-avatar" onClick={() => go('Settings')}>{initials}</button></header>
      {page === 'Overview' && <OverviewPage go={go} showResource={showResource} activity={activity} />}
      {page === 'My Library' && <LibraryPage go={go} showResource={showResource} saved={saved} activity={activity} onRemoveHistory={(id) => setActivity(current => { const next = current.filter(item => item.resourceId !== id); localStorage.setItem('cresa-reading-activity', JSON.stringify(next)); return next })} onComplete={(resource) => updateProgress(resource, activity.find(item => item.resourceId === resource.id)?.currentPage ?? 1, activity.find(item => item.resourceId === resource.id)?.currentPage ?? 1, true)} />}
      {page === 'Discover' && <DiscoverPage resources={searchResults} query={query} setQuery={setQuery} showResource={showResource} saved={saved} toggleSaved={toggleSaved} />}
      {page === 'Saved for later' && <SavedPage resources={resources.filter(item => saved.includes(item.id))} showResource={showResource} toggleSaved={toggleSaved} />}
      {page === 'Community' && <CommunityPage setToast={setToast} />}
      {page === 'Settings' && <SettingsPage user={user} token={getSessionToken()} setToast={setToast} onLogout={handleLogout} onDelete={handleDelete} onUserUpdate={updateUser} />}
      {page === 'Lecturer dashboard' && (user.role === 'lecturer' || user.role === 'administrator') && <LecturerDashboardPage setToast={setToast} user={user} token={getSessionToken()} />}
      {page === 'Resource details' && <ResourceDetailsPage resource={selected} saved={saved.includes(selected.id)} onSave={() => toggleSaved(selected)} onRead={() => { console.info('[Cresa Reader] Read now selected', { title: selected.title, url: selected.downloadUrl }); go('Reader') }} go={go} showResource={showResource} />}
      {page === 'Reader' && <ReaderPage resource={selected} onExit={() => go('Resource details')} setToast={setToast} initialPage={activity.find(item => item.resourceId === selected.id)?.currentPage ?? 1} aiEnabled={user.profile?.aiEnabled ?? true} onProgress={(currentPage, totalPages, completed, seconds) => updateProgress(selected, currentPage, totalPages, completed, seconds)} />}
    </section>
    {toast && <div className="blue-toast" role="status"><Icon name="check" size={17} />{toast}<button aria-label="Dismiss" onClick={() => setToast('')}><Icon name="close" size={15} /></button></div>}
  </main>
}
