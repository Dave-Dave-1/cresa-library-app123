import mysql from 'mysql2/promise'
import { existsSync, readFileSync } from 'node:fs'

const envFile = new URL('../.env', import.meta.url)
if (existsSync(envFile)) {
  for (const line of readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
    if (!match || process.env[match[1]] !== undefined) continue
    process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '')
  }
}

const databaseName = process.env.DB_NAME ?? 'cresa_library'
const connectionOptions = {
  host: process.env.DB_HOST ?? '127.0.0.1',
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER ?? 'cresa_app',
  password: process.env.DB_PASSWORD ?? '',
}

export const pool = mysql.createPool({
  ...connectionOptions,
  database: databaseName,
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT ?? 10),
  queueLimit: 0,
})

const schemaStatements = readFileSync(new URL('../database/schema.sql', import.meta.url), 'utf8')
  .replace(/CREATE DATABASE IF NOT EXISTS[\s\S]*?;\s*/i, '')
  .replace(/USE\s+`?\w+`?\s*;\s*/i, '')
  .split(/;\s*(?:\r?\n|$)/)
  .map(statement => statement.trim())
  .filter(Boolean)

export async function initializeDatabase() {
  const bootstrapConnection = await mysql.createConnection({
    ...connectionOptions,
    user: process.env.DB_BOOTSTRAP_USER || connectionOptions.user,
    password: process.env.DB_BOOTSTRAP_PASSWORD ?? connectionOptions.password,
  })

  try {
    await bootstrapConnection.query(`CREATE DATABASE IF NOT EXISTS \`${databaseName.replaceAll('`', '``')}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`)
  } finally {
    await bootstrapConnection.end()
  }

  for (const statement of schemaStatements) await pool.query(statement)
}

export async function requireDatabase() {
  await initializeDatabase()
  await pool.query('SELECT 1')
}
