import { createServer } from 'node:http'
import { randomUUID } from 'node:crypto'
import { createReadStream, existsSync, statSync } from 'node:fs'
import { basename, dirname, extname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { pool, requireDatabase } from './db.mjs'
import { createSessionToken, createVerificationCode, hashPassword, hashValue, matchesPassword } from './security.mjs'

const PORT = Number(process.env.PORT ?? 3001)
const CODE_TTL_MINUTES = 10
const SESSION_TTL_DAYS = 7
const allowedOrigin = process.env.CLIENT_ORIGIN ?? 'http://localhost:5173'
const serverDirectory = dirname(fileURLToPath(import.meta.url))
const booksDirectory = join(serverDirectory, '..', 'public', 'books')

const json = (response, status, body) => {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  })
  response.end(JSON.stringify(body))
}

const bookMimeType = filename => ({ '.pdf': 'application/pdf', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }[extname(filename).toLowerCase()] ?? 'application/octet-stream')
const streamBook = (request, response, requestedName) => {
  const filename = basename(decodeURIComponent(requestedName))
  const filePath = join(booksDirectory, filename)
  if (!filename || filePath !== join(booksDirectory, filename) || !existsSync(filePath)) return json(response, 404, { ok: false, error: 'Book file not found.' })
  const file = statSync(filePath)
  response.writeHead(200, { 'Content-Type': bookMimeType(filename), 'Content-Length': file.size, 'Content-Disposition': `inline; filename="${filename}"`, 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': allowedOrigin, 'Accept-Ranges': 'bytes' })
  if (request.method === 'HEAD') return response.end()
  createReadStream(filePath).on('error', () => { if (!response.headersSent) json(response, 500, { ok: false, error: 'Book file could not be read.' }); else response.destroy() }).pipe(response)
}

const readBody = request => new Promise((resolve, reject) => {
  let body = ''
  request.on('data', chunk => {
    body += chunk
    if (body.length > 20_000) reject(new Error('Payload too large.'))
  })
  request.on('end', () => {
    try { resolve(body ? JSON.parse(body) : {}) } catch { reject(new Error('Invalid JSON.')) }
  })
})

const validPassword = password => typeof password === 'string' && password.length >= 8 && /[A-Z]/.test(password) && /[a-z]/.test(password) && /\d/.test(password)
const validEmail = email => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
const normalizeIdentifier = identifier => String(identifier ?? '').trim()
const normalizeOptional = value => String(value ?? '').trim() || null
const authToken = request => request.headers.authorization?.startsWith('Bearer ') ? request.headers.authorization.slice(7) : null

const userForResponse = row => ({
  id: row.id,
  name: row.full_name,
  role: row.role,
  status: row.account_status,
  identifier: row.role === 'student' ? row.registration_number : row.lecturer_id,
  identifierType: row.role === 'student' ? 'registration_number' : 'lecturer_id',
  lecturerEmail: row.lecturer_email ?? undefined,
  profile: {
    avatarUrl: row.avatar_url ?? null,
    institution: row.institution ?? '',
    course: row.course ?? '',
    language: row.language ?? 'en',
    theme: row.theme ?? 'system',
    notificationsEnabled: Boolean(row.notifications_enabled ?? 1),
    aiEnabled: Boolean(row.ai_enabled ?? 1),
    showReadingActivity: Boolean(row.show_reading_activity ?? 1),
    saveChatHistory: Boolean(row.save_chat_history ?? 1),
  },
  verified: Boolean(row.is_verified),
})

async function findUserByIdentifier(identifier) {
  const [rows] = await pool.execute(
    'SELECT BIN_TO_UUID(u.id) AS id, u.full_name, u.registration_number, u.lecturer_id, u.lecturer_email, ' +
    'u.role, u.password_hash, u.is_verified, u.account_status, p.avatar_url, p.institution, p.course, ' +
    'p.language, p.theme, p.notifications_enabled, p.ai_enabled, p.show_reading_activity, p.save_chat_history ' +
    'FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id ' +
    'WHERE u.registration_number = ? OR u.lecturer_id = ? LIMIT 1',
    [identifier, identifier],
  )
  return rows[0] ?? null
}

async function getCurrentUser(request) {
  const token = authToken(request)
  if (!token) return null
  const [rows] = await pool.execute(
    'SELECT BIN_TO_UUID(u.id) AS id, u.full_name, u.registration_number, u.lecturer_id, u.lecturer_email, ' +
    'u.role, u.password_hash, u.is_verified, u.account_status, p.avatar_url, p.institution, p.course, ' +
    'p.language, p.theme, p.notifications_enabled, p.ai_enabled, p.show_reading_activity, p.save_chat_history ' +
    'FROM user_sessions s JOIN users u ON u.id = s.user_id ' +
    'LEFT JOIN user_profiles p ON p.user_id = u.id ' +
    'WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > CURRENT_TIMESTAMP LIMIT 1',
    [hashValue(token)],
  )
  const user = rows[0] ?? null
  if (user) await pool.execute('UPDATE user_sessions SET last_seen_at = CURRENT_TIMESTAMP WHERE token_hash = ?', [hashValue(token)])
  return user
}

async function requireActiveUser(request, response) {
  const user = await getCurrentUser(request)
  if (!user) { json(response, 401, { ok: false, error: 'Authentication is required.' }); return null }
  if (user.account_status === 'suspended') { json(response, 403, { ok: false, error: 'This account is suspended.' }); return null }
  if (user.account_status !== 'active') { json(response, 403, { ok: false, error: 'This account is not active.' }); return null }
  return user
}

async function requireAdministrator(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return null
  if (user.role !== 'administrator') { json(response, 403, { ok: false, error: 'Administrator permission is required.' }); return null }
  return user
}

async function recordAudit(actorId, action, entityType, entityId = null, metadata = null) {
  await pool.execute(
    'INSERT INTO audit_logs (actor_id, action, entity_type, entity_id, metadata) VALUES (UUID_TO_BIN(?), ?, ?, ' +
    'CASE WHEN ? IS NULL THEN NULL ELSE UUID_TO_BIN(?) END, ?)',
    [actorId, action, entityType, entityId, entityId, metadata ? JSON.stringify(metadata) : null],
  )
}

async function issueCode(userId, purpose, details) {
  const code = createVerificationCode()
  await pool.execute(
    'UPDATE verification_tokens SET used_at = CURRENT_TIMESTAMP WHERE user_id = UUID_TO_BIN(?) AND purpose = ? AND used_at IS NULL',
    [userId, purpose],
  )
  await pool.execute(
    'INSERT INTO verification_tokens (user_id, code_hash, purpose, expires_at) VALUES (UUID_TO_BIN(?), ?, ?, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? MINUTE))',
    [userId, hashValue(code), purpose, CODE_TTL_MINUTES],
  )
  console.log('\n[Cresa verification] Purpose: ' + purpose)
  console.log('Account: ' + details.identifier)
  console.log('Email: ' + details.email)
  console.log('Verification code: ' + code + ' (expires in ' + CODE_TTL_MINUTES + ' minutes)\n')
}

async function createSession(userId) {
  const token = createSessionToken()
  await pool.execute(
    'INSERT INTO user_sessions (id, user_id, token_hash, expires_at) VALUES (UUID_TO_BIN(?), UUID_TO_BIN(?), ?, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? DAY))',
    [randomUUID(), userId, hashValue(token), SESSION_TTL_DAYS],
  )
  return token
}

async function register(request, response) {
  const body = await readBody(request)
  const name = String(body.name ?? '').trim()
  const identifier = normalizeIdentifier(body.identifier)
  const password = String(body.password ?? '')
  const role = body.role === 'lecturer' ? 'lecturer' : body.role === 'student' ? 'student' : null
  const lecturerEmail = String(body.lecturerEmail ?? '').trim().toLowerCase()
  if (!role || name.length < 2 || !identifier || !validPassword(password)) return json(response, 400, { ok: false, error: 'Provide a name, identifier, valid role, and strong password.' })
  if (role === 'lecturer' && !validEmail(lecturerEmail)) return json(response, 400, { ok: false, error: 'A valid lecturer email address is required.' })
  if (await findUserByIdentifier(identifier)) return json(response, 409, { ok: false, error: 'An account already exists for this identifier.' })
  const id = randomUUID()
  await pool.execute(
    'INSERT INTO users (id, full_name, registration_number, lecturer_id, lecturer_email, role, password_hash, is_verified, account_status) VALUES (UUID_TO_BIN(?), ?, ?, ?, ?, ?, ?, ?, ?)',
    [id, name, role === 'student' ? identifier : null, role === 'lecturer' ? identifier : null, role === 'lecturer' ? lecturerEmail : null, role, await hashPassword(password), role === 'student', role === 'student' ? 'active' : 'pending'],
  )
  await pool.execute('INSERT INTO user_profiles (user_id) VALUES (UUID_TO_BIN(?))', [id])
  if (role === 'lecturer') await issueCode(id, 'account_verification', { identifier, email: lecturerEmail })
  return json(response, 201, { ok: true, requiresVerification: role === 'lecturer' })
}

async function verifyLecturer(request, response) {
  const body = await readBody(request)
  const identifier = normalizeIdentifier(body.lecturerId)
  const code = String(body.code ?? '')
  if (!identifier || !/^\d{6}$/.test(code)) return json(response, 400, { ok: false, error: 'Lecturer ID and a six-digit code are required.' })
  const user = await findUserByIdentifier(identifier)
  if (!user || user.role !== 'lecturer') return json(response, 404, { ok: false, error: 'Lecturer account not found.' })
  const [rows] = await pool.execute(
    'SELECT id, code_hash, attempt_count FROM verification_tokens WHERE user_id = UUID_TO_BIN(?) AND purpose = ? AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP ORDER BY created_at DESC LIMIT 1',
    [user.id, 'account_verification'],
  )
  const token = rows[0]
  if (!token) return json(response, 400, { ok: false, error: 'Code expired or unavailable. Request a new code.' })
  if (token.attempt_count >= 5) return json(response, 429, { ok: false, error: 'Too many attempts. Request a new code.' })
  if (hashValue(code) !== token.code_hash) {
    await pool.execute('UPDATE verification_tokens SET attempt_count = attempt_count + 1 WHERE id = ?', [token.id])
    return json(response, 400, { ok: false, error: 'The verification code is incorrect.' })
  }
  await pool.execute('UPDATE verification_tokens SET used_at = CURRENT_TIMESTAMP WHERE id = ?', [token.id])
  await pool.execute("UPDATE users SET is_verified = TRUE, account_status = 'active' WHERE id = UUID_TO_BIN(?)", [user.id])
  return json(response, 200, { ok: true })
}

async function resendLecturerCode(request, response) {
  const body = await readBody(request)
  const identifier = normalizeIdentifier(body.lecturerId)
  const user = await findUserByIdentifier(identifier)
  if (!user || user.role !== 'lecturer' || !user.lecturer_email) return json(response, 404, { ok: false, error: 'Lecturer account not found.' })
  await issueCode(user.id, 'account_verification', { identifier, email: user.lecturer_email })
  return json(response, 200, { ok: true })
}

async function login(request, response) {
  const body = await readBody(request)
  const identifier = normalizeIdentifier(body.identifier)
  const password = String(body.password ?? '')
  const user = await findUserByIdentifier(identifier)
  if (!user || !(await matchesPassword(password, user.password_hash))) return json(response, 401, { ok: false, error: 'The identifier or password is incorrect.' })
  if (user.account_status === 'suspended') return json(response, 403, { ok: false, error: 'This account is suspended.' })
  if (!user.is_verified || user.account_status !== 'active') return json(response, 403, { ok: false, error: 'Verify your account before signing in.' })
  const sessionToken = await createSession(user.id)
  await pool.execute('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = UUID_TO_BIN(?)', [user.id])
  return json(response, 200, { ok: true, user: userForResponse(user), sessionToken })
}

async function getProfile(request, response) {
  const user = await requireActiveUser(request, response)
  if (user) json(response, 200, { ok: true, user: userForResponse(user) })
}

async function updateProfile(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  const body = await readBody(request)
  const fullName = String(body.name ?? '').trim()
  if (fullName.length < 2 || fullName.length > 150) return json(response, 400, { ok: false, error: 'Enter a valid full name.' })
  const institution = normalizeOptional(body.institution)
  const course = normalizeOptional(body.course)
  const avatarUrl = normalizeOptional(body.avatarUrl)
  await pool.execute('UPDATE users SET full_name = ? WHERE id = UUID_TO_BIN(?)', [fullName, user.id])
  await pool.execute('UPDATE user_profiles SET institution = ?, course = ?, avatar_url = ? WHERE user_id = UUID_TO_BIN(?)', [institution, course, avatarUrl, user.id])
  await recordAudit(user.id, 'profile_updated', 'user', user.id)
  return getProfile(request, response)
}

async function updatePreferences(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  const body = await readBody(request)
  const theme = ['light', 'dark', 'system'].includes(body.theme) ? body.theme : 'system'
  const language = /^[a-z]{2}(-[A-Z]{2})?$/.test(String(body.language ?? '')) ? body.language : 'en'
  const values = [Boolean(body.notificationsEnabled), Boolean(body.aiEnabled), Boolean(body.showReadingActivity), Boolean(body.saveChatHistory), theme, language, user.id]
  await pool.execute(
    'UPDATE user_profiles SET notifications_enabled = ?, ai_enabled = ?, show_reading_activity = ?, save_chat_history = ?, theme = ?, language = ? WHERE user_id = UUID_TO_BIN(?)',
    values,
  )
  await recordAudit(user.id, 'preferences_updated', 'user', user.id)
  return getProfile(request, response)
}

async function changePassword(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  const body = await readBody(request)
  const currentPassword = String(body.currentPassword ?? '')
  const nextPassword = String(body.newPassword ?? '')
  if (!(await matchesPassword(currentPassword, user.password_hash))) return json(response, 400, { ok: false, error: 'Your current password is incorrect.' })
  if (!validPassword(nextPassword)) return json(response, 400, { ok: false, error: 'Use a stronger password.' })
  await pool.execute('UPDATE users SET password_hash = ? WHERE id = UUID_TO_BIN(?)', [await hashPassword(nextPassword), user.id])
  await pool.execute('UPDATE user_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE user_id = UUID_TO_BIN(?) AND token_hash <> ?', [user.id, hashValue(authToken(request) ?? '')])
  await recordAudit(user.id, 'password_changed', 'user', user.id)
  return json(response, 200, { ok: true })
}

async function requestEmailChange(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  if (user.role !== 'lecturer') return json(response, 403, { ok: false, error: 'Only lecturer accounts have a verification email.' })
  const body = await readBody(request)
  const email = String(body.email ?? '').trim().toLowerCase()
  if (!validEmail(email)) return json(response, 400, { ok: false, error: 'Enter a valid email address.' })
  await pool.execute('UPDATE users SET pending_lecturer_email = ? WHERE id = UUID_TO_BIN(?)', [email, user.id])
  await issueCode(user.id, 'email_change', { identifier: user.lecturer_id, email })
  return json(response, 200, { ok: true })
}

async function confirmEmailChange(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  const body = await readBody(request)
  const code = String(body.code ?? '')
  const [rows] = await pool.execute(
    'SELECT id, code_hash, attempt_count FROM verification_tokens WHERE user_id = UUID_TO_BIN(?) AND purpose = ? AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP ORDER BY created_at DESC LIMIT 1',
    [user.id, 'email_change'],
  )
  const token = rows[0]
  if (!token || !/^\d{6}$/.test(code)) return json(response, 400, { ok: false, error: 'A valid verification code is required.' })
  if (token.attempt_count >= 5) return json(response, 429, { ok: false, error: 'Too many attempts. Request a new code.' })
  if (hashValue(code) !== token.code_hash) { await pool.execute('UPDATE verification_tokens SET attempt_count = attempt_count + 1 WHERE id = ?', [token.id]); return json(response, 400, { ok: false, error: 'The verification code is incorrect.' }) }
  await pool.execute('UPDATE verification_tokens SET used_at = CURRENT_TIMESTAMP WHERE id = ?', [token.id])
  await pool.execute('UPDATE users SET lecturer_email = pending_lecturer_email, pending_lecturer_email = NULL WHERE id = UUID_TO_BIN(?)', [user.id])
  await recordAudit(user.id, 'lecturer_email_changed', 'user', user.id)
  return getProfile(request, response)
}

async function deleteOwnAccount(request, response) {
  const user = await requireActiveUser(request, response)
  if (!user) return
  await pool.execute("UPDATE users SET account_status = 'suspended' WHERE id = UUID_TO_BIN(?)", [user.id])
  await pool.execute('UPDATE user_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE user_id = UUID_TO_BIN(?)', [user.id])
  await recordAudit(user.id, 'account_deletion_requested', 'user', user.id)
  return json(response, 200, { ok: true })
}

async function listUsers(request, response) {
  const admin = await requireAdministrator(request, response)
  if (!admin) return
  const [rows] = await pool.execute(
    'SELECT BIN_TO_UUID(id) AS id, full_name, registration_number, lecturer_id, lecturer_email, role, is_verified, account_status, created_at, last_login_at FROM users ORDER BY created_at DESC LIMIT 200',
  )
  return json(response, 200, { ok: true, users: rows.map(userForResponse) })
}

async function updateUserAccess(request, response, id) {
  const admin = await requireAdministrator(request, response)
  if (!admin) return
  const body = await readBody(request)
  const status = ['active', 'pending', 'suspended'].includes(body.status) ? body.status : null
  const role = ['student', 'lecturer', 'administrator'].includes(body.role) ? body.role : null
  if (!status && !role) return json(response, 400, { ok: false, error: 'Choose an account status or role.' })
  if (id === admin.id && (status === 'suspended' || role && role !== 'administrator')) return json(response, 400, { ok: false, error: 'Administrators cannot remove their own access.' })
  if (status && role) await pool.execute('UPDATE users SET account_status = ?, role = ? WHERE id = UUID_TO_BIN(?)', [status, role, id])
  else if (status) await pool.execute('UPDATE users SET account_status = ? WHERE id = UUID_TO_BIN(?)', [status, id])
  else await pool.execute('UPDATE users SET role = ? WHERE id = UUID_TO_BIN(?)', [role, id])
  await recordAudit(admin.id, 'user_access_updated', 'user', id, { status, role })
  return json(response, 200, { ok: true })
}

async function deleteStudent(request, response, id) {
  const admin = await requireAdministrator(request, response)
  if (!admin) return
  const [rows] = await pool.execute('SELECT role, full_name FROM users WHERE id = UUID_TO_BIN(?)', [id])
  const student = rows[0]
  if (!student || student.role !== 'student') return json(response, 404, { ok: false, error: 'Student account not found.' })
  await recordAudit(admin.id, 'student_account_deleted', 'user', id, { name: student.full_name })
  await pool.execute('DELETE FROM users WHERE id = UUID_TO_BIN(?)', [id])
  return json(response, 200, { ok: true })
}

const server = createServer(async (request, response) => {
    if (request.method === 'OPTIONS') return json(response, 204, {})
    const bookMatch = request.url?.match(/^\/api\/books\/([^/?#]+)$/)
    if ((request.method === 'GET' || request.method === 'HEAD') && bookMatch) return streamBook(request, response, bookMatch[1])
  try {
    if (request.method === 'POST' && request.url === '/api/auth/register') return register(request, response)
    if (request.method === 'POST' && request.url === '/api/auth/lecturer/verify') return verifyLecturer(request, response)
    if (request.method === 'POST' && request.url === '/api/auth/lecturer/resend-code') return resendLecturerCode(request, response)
    if (request.method === 'POST' && request.url === '/api/auth/login') return login(request, response)
    if (request.method === 'GET' && request.url === '/api/me') return getProfile(request, response)
    if (request.method === 'PATCH' && request.url === '/api/me/profile') return updateProfile(request, response)
    if (request.method === 'PATCH' && request.url === '/api/me/preferences') return updatePreferences(request, response)
    if (request.method === 'POST' && request.url === '/api/me/change-password') return changePassword(request, response)
    if (request.method === 'POST' && request.url === '/api/me/email-change/request') return requestEmailChange(request, response)
    if (request.method === 'POST' && request.url === '/api/me/email-change/confirm') return confirmEmailChange(request, response)
    if (request.method === 'DELETE' && request.url === '/api/me') return deleteOwnAccount(request, response)
    if (request.method === 'GET' && request.url === '/api/admin/users') return listUsers(request, response)
    const accessMatch = request.url?.match(/^\/api\/admin\/users\/([0-9a-f-]{36})\/access$/i)
    if (request.method === 'PATCH' && accessMatch) return updateUserAccess(request, response, accessMatch[1])
    const studentMatch = request.url?.match(/^\/api\/admin\/users\/([0-9a-f-]{36})$/i)
    if (request.method === 'DELETE' && studentMatch) return deleteStudent(request, response, studentMatch[1])
    return json(response, 404, { ok: false, error: 'Route not found.' })
  } catch (error) {
    console.error(error)
    return json(response, 500, { ok: false, error: 'The server could not complete this request.' })
  }
})

requireDatabase()
  .then(() => server.listen(PORT, () => console.log('Cresa API server running on http://localhost:' + PORT)))
  .catch(error => { console.error('Database connection failed.', error.message); process.exitCode = 1 })
